CROSS DJ PRO v2
===============
Your app (edit these 3 files):  app/src/main/assets/
  index.html  = screens (Mix, Library, Auto DJ tabs)
  style.css   = colours and look
  app.js      = all features (sections are labelled at the top)
  logo.png    = logo (app icons are in app/src/main/res/mipmap-*)

Preview in a browser: open assets/index.html in Chrome.

Build the APK with GitHub: upload CrossDJPro.zip + .github/workflows/build.yml,
then Actions > Build APK > Artifacts.
