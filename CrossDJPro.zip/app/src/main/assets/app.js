'use strict';
/* =====================================================================
   CROSS DJ PRO  v2
   1 Helpers & knobs | 2 Audio engine | 3 Deck | 4 Mixer | 5 Demo songs
   6 Sampler | 7 Library | 8 Auto DJ | 9 Recording | 10 Start-up
   ===================================================================== */

/* ---------- 1. HELPERS & KNOBS ---------- */
const $ = (s, r = document) => r.querySelector(s);
const sleep = ms => new Promise(r => setTimeout(r, ms));
let ctx, master, comp, analyser, recDest, noiseBuf;
const decks = {};
const fmt = t => { t = Math.max(0, t || 0); const m = Math.floor(t / 60), s = Math.floor(t % 60); return m + ':' + (s < 10 ? '0' : '') + s; };
let statusTimer;
function status(msg) {
  const el = $('#status'); el.textContent = msg;
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => { el.textContent = 'Cross DJ Pro'; }, 6000);
}
function holdRepeat(btn, fn) {
  let iv, to;
  const stop = () => { clearTimeout(to); clearInterval(iv); };
  btn.addEventListener('pointerdown', e => { e.preventDefault(); fn(); to = setTimeout(() => { iv = setInterval(fn, 70); }, 350); });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => btn.addEventListener(ev, stop));
}
function makeKnob(host, label, min, max, val, def, onInput) {
  host.classList.add('knob');
  host.innerHTML = '<div class="kn"><i></i></div><small>' + label + '</small>';
  const i = host.querySelector('i'), kn = host.querySelector('.kn');
  const k = { value: val, def };
  const show = () => { i.style.transform = 'rotate(' + (-135 + (k.value - min) / (max - min) * 270) + 'deg)'; };
  k.set = v => { k.value = Math.max(min, Math.min(max, v)); show(); onInput(k.value); };
  let sy, sv, last = 0;
  host.addEventListener('pointerdown', e => {
    e.preventDefault(); host.setPointerCapture(e.pointerId);
    const now = Date.now(); if (now - last < 300) { k.set(def); } last = now;
    sy = e.clientY; sv = k.value;
  });
  host.addEventListener('pointermove', e => {
    if (sy === undefined || !host.hasPointerCapture(e.pointerId)) return;
    k.set(sv + (sy - e.clientY) / 130 * (max - min));
  });
  const end = () => { sy = undefined; };
  host.addEventListener('pointerup', end); host.addEventListener('pointercancel', end);
  show();
  return k;
}

/* ---------- 2. AUDIO ENGINE ---------- */
function initAudio() {
  if (ctx) { if (ctx.state === 'suspended') ctx.resume(); return; }
  ctx = new (window.AudioContext || window.webkitAudioContext)();
  master = ctx.createGain(); master.gain.value = +$('#master').value;
  comp = ctx.createDynamicsCompressor();
  comp.threshold.value = -6; comp.knee.value = 6; comp.ratio.value = 12; comp.attack.value = 0.003; comp.release.value = 0.12;
  analyser = ctx.createAnalyser(); analyser.fftSize = 1024;
  recDest = ctx.createMediaStreamDestination();
  master.connect(comp); comp.connect(analyser); analyser.connect(ctx.destination); comp.connect(recDest);
  noiseBuf = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate);
  const nd = noiseBuf.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
  Object.values(decks).forEach(d => d.buildAudio());
  applyCross();
}
function makeImpulse(sec) {
  const len = Math.floor(ctx.sampleRate * sec), b = ctx.createBuffer(2, len, ctx.sampleRate);
  for (let c = 0; c < 2; c++) { const d = b.getChannelData(c); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
  return b;
}
function setG(node, v) { node.gain.setTargetAtTime(v, ctx.currentTime, 0.015); }
function detectBPM(buf) {
  const sr = buf.sampleRate, ch = buf.getChannelData(0), hop = Math.round(sr / 200);
  const n = Math.floor(Math.min(ch.length, sr * 90) / hop);
  if (n < 400) return 0;
  const env = new Float32Array(n); let lp = 0;
  for (let i = 0; i < n; i++) { let sum = 0; for (let j = 0; j < hop; j++) { lp += 0.1 * (ch[i * hop + j] - lp); sum += lp * lp; } env[i] = Math.sqrt(sum / hop); }
  const on = new Float32Array(n); for (let i = 1; i < n; i++) on[i] = Math.max(0, env[i] - env[i - 1]);
  const minLag = Math.floor(200 * 60 / 180), maxLag = Math.ceil(200 * 60 / 70);
  const ac = new Float32Array(maxLag + 2); let best = minLag, bv = -1;
  for (let lag = minLag - 1; lag <= maxLag + 1; lag++) {
    let s = 0; for (let i = 0; i + lag < n; i++) s += on[i] * on[i + lag];
    ac[lag] = s / (n - lag);
    if (lag >= minLag && lag <= maxLag && ac[lag] > bv) { bv = ac[lag]; best = lag; }
  }
  const a = ac[best - 1], b = ac[best], c = ac[best + 1], den = a - 2 * b + c;
  let bpm = 12000 / (best + (den !== 0 ? 0.5 * (a - c) / den : 0));
  while (bpm < 80) bpm *= 2; while (bpm >= 170) bpm /= 2;
  return Math.round(bpm * 10) / 10;
}

/* ---------- 3. DECK ---------- */
const FX_LIST = [['echo', 'ECHO'], ['reverb', 'REVERB'], ['flanger', 'FLANGER'], ['phaser', 'PHASER'], ['crush', 'CRUSH'], ['gate', 'GATE'], ['wobble', 'WOBBLE'], ['stutter', 'STUTTER']];
class Deck {
  constructor(id) {
    this.id = id; this.other = null;
    this.buf = null; this.src = null; this.playing = false; this.loading = false; this.ended = false;
    this.offset = 0; this.startedAt = 0;
    this.pitch = 0; this.nudge = 0; this.hold = 1; this.brakeMul = 1; this.braking = null;
    this.bpm = 0; this.cue = 0; this.hot = [null, null, null, null];
    this.loop = null; this.peaks = null; this.name = ''; this.item = null;
    this.fxOn = false; this.preview = false; this.dirty = true;
    this.vol = 1; this.xf = 1; this.angle = 0; this.touch = null; this.vinyl = null; this.vinylKey = '';
    this.el = $('#deck' + id);
    this.buildUI();
  }
  get tempo() { return (1 + this.pitch / 100) * (1 + this.nudge); }
  get eff() { return this.tempo * this.hold * this.brakeMul; }
  q(s) { return this.el.querySelector(s); }

  buildUI() {
    const num = this.id === 'A' ? '01' : '02';
    this.el.innerHTML = `
      <div class="dh"><b class="dn">DECK ${this.id}</b><b class="dnum">${num}</b></div>
      <canvas class="platter" data-r="platter"></canvas>
      <div class="tname" data-r="name">No track loaded</div>
      <div class="times"><span data-r="time">0:00</span><span data-r="rem">-0:00</span></div>
      <div class="bpmrow"><button data-a="bpm-">−</button><b data-r="bpm">--</b><small>BPM</small><button data-a="bpm+">+</button></div>
      <div class="wave"><canvas data-r="wave"></canvas></div>
      <div class="r3" style="margin-top:7px"><button data-a="load">LOAD</button><button data-a="demo">DEMO</button><button data-a="sync">SYNC</button></div>
      <div class="r3" style="margin-top:5px"><button data-a="cue" class="cue">CUE</button><button data-a="play" class="playbtn">▶</button><button data-a="brake">BRAKE</button></div>
      <div class="cap">LOOP (BEATS)</div>
      <div class="r4"><button data-loop="1">1</button><button data-loop="2">2</button><button data-loop="4">4</button><button data-loop="8">8</button></div>
      <div class="cap">HOT CUES</div>
      <div class="r4 hot"><button data-hot="0">1</button><button data-hot="1">2</button><button data-hot="2">3</button><button data-hot="3">4</button></div>
      <div class="cap">EQ + FILTER</div>
      <div class="knobs"><div data-k="hi"></div><div data-k="mid"></div><div data-k="lo"></div><div data-k="flt"></div></div>
      <div class="cap">PITCH · VOLUME</div>
      <label class="sl"><span>Pitch</span><input data-r="pitch" type="range" min="-16" max="16" step="0.1" value="0"></label>
      <label class="sl"><span>Vol</span><input data-r="vol" type="range" min="0" max="1" step="0.01" value="1"></label>
      <div class="r3" style="margin-top:3px;grid-template-columns:1fr 1fr"><button data-nudge="-1">◀ SLOW</button><button data-nudge="1">FAST ▶</button></div>
      <div class="cap">EFFECTS</div>
      <div class="fxrow"><select data-r="fxType">${FX_LIST.map(f => `<option value="${f[0]}">${f[1]}</option>`).join('')}</select><button data-a="fx">FX OFF</button></div>
      <label class="sl"><span>Amount</span><input data-r="fxAmt" type="range" min="0" max="1" step="0.01" value="0.5"></label>`;

    const on = (sel, ev, fn) => this.el.querySelectorAll(sel).forEach(e => e.addEventListener(ev, fn));
    on('[data-a="load"]', 'click', () => { fileTarget = this; $('#fileDeck').value = ''; $('#fileDeck').click(); });
    on('[data-a="demo"]', 'click', () => { initAudio(); const k = this.demoIdx === undefined ? (this.id === 'A' ? 0 : 1) : this.demoIdx; this.demoIdx = (k + 1) % 2; loadItem(demoItem(k), this); });
    on('[data-a="play"]', 'click', () => { initAudio(); this.togglePlay(); });
    on('[data-a="sync"]', 'click', () => this.sync());
    on('[data-a="brake"]', 'click', () => this.brake());
    on('[data-a="fx"]', 'click', () => { this.fxOn = !this.fxOn; this.applyFx(); });
    holdRepeat(this.q('[data-a="bpm-"]'), () => this.adjBpm(-0.1));
    holdRepeat(this.q('[data-a="bpm+"]'), () => this.adjBpm(0.1));

    const cue = this.q('[data-a="cue"]');
    cue.addEventListener('pointerdown', e => { e.preventDefault(); initAudio(); this.cueDown(); });
    ['pointerup', 'pointercancel'].forEach(ev => cue.addEventListener(ev, () => this.cueUp()));
    on('[data-loop]', 'click', e => this.toggleLoop(+e.currentTarget.dataset.loop));

    this.el.querySelectorAll('[data-hot]').forEach(p => {
      let t, held = false;
      p.addEventListener('pointerdown', e => { e.preventDefault(); held = false; t = setTimeout(() => { held = true; this.clearHot(+p.dataset.hot); }, 700); });
      p.addEventListener('pointerup', () => { clearTimeout(t); if (!held) this.hotTap(+p.dataset.hot); });
      p.addEventListener('pointercancel', () => clearTimeout(t));
    });
    this.el.querySelectorAll('[data-nudge]').forEach(b => {
      const s = +b.dataset.nudge;
      b.addEventListener('pointerdown', e => { e.preventDefault(); b.classList.add('on'); this.setNudge(0.06 * s); });
      const off = () => { b.classList.remove('on'); this.setNudge(0); };
      ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => b.addEventListener(ev, off));
    });

    const kn = this.el.querySelectorAll('[data-k]');
    this.k = {};
    const mk = (key, label) => { this.k[key] = makeKnob(this.q('[data-k="' + key + '"]'), label, -1, 1, 0, 0, key === 'flt' ? () => this.applyFilter() : () => this.applyEq()); };
    mk('hi', 'HI'); mk('mid', 'MID'); mk('lo', 'LOW'); mk('flt', 'FILTER');

    this.q('[data-r="pitch"]').addEventListener('input', e => this.setPitch(+e.target.value));
    this.q('[data-r="vol"]').addEventListener('input', e => { this.vol = +e.target.value; applyCross(); });
    this.q('[data-r="fxAmt"]').addEventListener('input', () => this.applyFx());
    this.q('[data-r="fxType"]').addEventListener('change', () => this.applyFx());

    const wave = this.q('[data-r="wave"]');
    wave.addEventListener('pointerdown', e => {
      if (!this.buf) return;
      const r = wave.getBoundingClientRect();
      this.seek(Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * this.buf.duration);
    });

    // vinyl: hold / spin / scrub
    const pl = this.q('[data-r="platter"]');
    const angleAt = e => { const r = pl.getBoundingClientRect(); return Math.atan2(e.clientY - (r.top + r.height / 2), e.clientX - (r.left + r.width / 2)) * 180 / Math.PI; };
    pl.addEventListener('pointerdown', e => {
      e.preventDefault(); pl.setPointerCapture(e.pointerId);
      initAudio();
      this.touch = { a: angleAt(e), t: performance.now(), w: 0 };
      if (this.buf && this.playing) this.setHold(0);
    });
    pl.addEventListener('pointermove', e => {
      if (!this.touch || !this.buf) return;
      const a = angleAt(e); let d = a - this.touch.a; if (d > 180) d -= 360; if (d < -180) d += 360;
      const now = performance.now(), dt = Math.max(0.008, (now - this.touch.t) / 1000);
      this.angle += d;
      if (this.playing) {
        this.touch.w = this.touch.w * 0.6 + (d / dt) * 0.4;
        this.setHold(Math.max(0, Math.min(4, this.touch.w / (200 * this.tempo))));
      } else { this.seek(this.pos() + d / 360 * 1.8); }
      this.touch.a = a; this.touch.t = now;
    });
    const rel = () => { if (this.touch) { this.touch = null; if (this.playing) this.setHold(1); } };
    pl.addEventListener('pointerup', rel); pl.addEventListener('pointercancel', rel);
  }

  buildAudio() {
    const c = ctx;
    const mkB = (type, f, q) => { const b = c.createBiquadFilter(); b.type = type; b.frequency.value = f; if (q) b.Q.value = q; return b; };
    this.trim = c.createGain();
    this.lo = mkB('lowshelf', 250); this.mid = mkB('peaking', 1200, 0.8); this.hi = mkB('highshelf', 3500);
    this.flt = mkB('lowpass', 20000, 0.9);
    this.dry = c.createGain(); this.out = c.createGain();
    this.trim.connect(this.lo); this.lo.connect(this.mid); this.mid.connect(this.hi); this.hi.connect(this.flt);
    this.flt.connect(this.dry); this.dry.connect(this.out); this.out.connect(master);
    // --- send effects ---
    this.fxIn = c.createGain(); this.fxIn.gain.value = 0; this.flt.connect(this.fxIn);
    this.dl = c.createDelay(2); this.dl.delayTime.value = 0.375; this.fb = c.createGain(); this.fb.gain.value = 0.45; this.echoOut = c.createGain();
    this.fxIn.connect(this.dl); this.dl.connect(this.echoOut); this.dl.connect(this.fb); this.fb.connect(this.dl); this.echoOut.connect(this.out);
    this.conv = c.createConvolver(); this.conv.buffer = makeImpulse(2.2); this.revOut = c.createGain();
    this.fxIn.connect(this.conv); this.conv.connect(this.revOut); this.revOut.connect(this.out);
    this.fl = c.createDelay(0.05); this.fl.delayTime.value = 0.004;
    const lfo = c.createOscillator(); lfo.frequency.value = 0.3; const lfoG = c.createGain(); lfoG.gain.value = 0.003;
    lfo.connect(lfoG); lfoG.connect(this.fl.delayTime); lfo.start();
    this.flFb = c.createGain(); this.flFb.gain.value = 0.5; this.flOut = c.createGain();
    this.fxIn.connect(this.fl); this.fl.connect(this.flOut); this.fl.connect(this.flFb); this.flFb.connect(this.fl); this.flOut.connect(this.out);
    // phaser (4 all-pass stages swept by an LFO)
    const ap = [0, 1, 2, 3].map(() => mkB('allpass', 700, 0.7));
    const pl = c.createOscillator(); pl.frequency.value = 0.4; const plG = c.createGain(); plG.gain.value = 500;
    pl.connect(plG); ap.forEach(a => plG.connect(a.frequency)); pl.start();
    this.phOut = c.createGain();
    this.fxIn.connect(ap[0]); ap[0].connect(ap[1]); ap[1].connect(ap[2]); ap[2].connect(ap[3]); ap[3].connect(this.phOut); this.phOut.connect(this.out);
    // --- insert effects (replace part of the dry signal) ---
    this.ws = c.createWaveShaper(); const cv = new Float32Array(1024); for (let i = 0; i < 1024; i++) cv[i] = Math.round((i / 511.5 - 1) * 4) / 4; this.ws.curve = cv;
    this.crushOut = c.createGain(); this.flt.connect(this.ws); this.ws.connect(this.crushOut); this.crushOut.connect(this.out);
    this.gateG = c.createGain(); this.gateG.gain.value = 0.5; this.gateLfo = c.createOscillator(); this.gateLfo.type = 'square'; this.gateLfo.frequency.value = 4;
    const gl = c.createGain(); gl.gain.value = 0.5; this.gateLfo.connect(gl); gl.connect(this.gateG.gain); this.gateLfo.start();
    this.gateOut = c.createGain(); this.flt.connect(this.gateG); this.gateG.connect(this.gateOut); this.gateOut.connect(this.out);
    this.wob = mkB('lowpass', 900, 6); this.wobLfo = c.createOscillator(); this.wobLfo.frequency.value = 1;
    const wg = c.createGain(); wg.gain.value = 750; this.wobLfo.connect(wg); wg.connect(this.wob.frequency); this.wobLfo.start();
    this.wobOut = c.createGain(); this.flt.connect(this.wob); this.wob.connect(this.wobOut); this.wobOut.connect(this.out);
    ['echoOut', 'revOut', 'flOut', 'phOut', 'crushOut', 'gateOut', 'wobOut'].forEach(n => { this[n].gain.value = 0; });
    this.applyEq(); this.applyFilter(); this.applyFx(); this.afterRate();
  }

  /* --- knobs & fx --- */
  applyEq() {
    if (!this.lo) return;
    const db = v => v < 0 ? v * 40 : v * 6;
    this.lo.gain.value = db(this.k.lo.value); this.mid.gain.value = db(this.k.mid.value); this.hi.gain.value = db(this.k.hi.value);
  }
  applyFilter() {
    if (!this.flt) return;
    const v = this.k.flt.value;
    if (Math.abs(v) < 0.03) { this.flt.type = 'lowpass'; this.flt.frequency.value = 20000; }
    else if (v < 0) { this.flt.type = 'lowpass'; this.flt.frequency.value = 200 * Math.pow(100, v + 1); }
    else { this.flt.type = 'highpass'; this.flt.frequency.value = 20 * Math.pow(400, v); }
  }
  applyFx() {
    const type = this.q('[data-r="fxType"]').value, amt = +this.q('[data-r="fxAmt"]').value, on = this.fxOn;
    const btn = this.q('[data-a="fx"]'); btn.classList.toggle('on', on); btn.textContent = on ? 'FX ON' : 'FX OFF';
    const st = this.loop && this.loop.beats === 0.25;
    if (this.buf) { if (type === 'stutter' && on && !st) this.toggleLoop(0.25); else if (st && !(type === 'stutter' && on)) this.clearLoop(); }
    if (!this.fxIn) return;
    const send = { echo: 'echoOut', reverb: 'revOut', flanger: 'flOut', phaser: 'phOut' }, ins = { crush: 'crushOut', gate: 'gateOut', wobble: 'wobOut' };
    ['echoOut', 'revOut', 'flOut', 'phOut', 'crushOut', 'gateOut', 'wobOut'].forEach(n => setG(this[n], 0));
    setG(this.fxIn, 0); setG(this.dry, 1);
    if (send[type]) { setG(this[send[type]], type === 'reverb' ? 1.4 : 1); if (on) setG(this.fxIn, amt); }
    else if (ins[type] && on) { setG(this[ins[type]], amt); setG(this.dry, 1 - amt); }
    this.updateTempoFx();
  }
  updateTempoFx() {
    if (!this.dl) return;
    const bps = (this.bpm || 120) * this.tempo / 60;
    this.dl.delayTime.value = Math.min(1.9, Math.max(0.05, 0.75 / bps));
    this.gateLfo.frequency.value = bps * 2; this.wobLfo.frequency.value = bps / 2;
  }
  setCross(g) { this.xf = g; if (this.out) this.out.gain.value = this.vol * g; }

  /* --- speed --- */
  setPitch(p) { if (this.playing) this.rebase(); this.pitch = p; this.afterRate(); }
  setNudge(n) { if (this.playing) this.rebase(); this.nudge = n; this.afterRate(); }
  setHold(h) { if (this.playing) this.rebase(); this.hold = h; this.afterRate(); }
  setBrakeMul(m) { if (this.playing) this.rebase(); this.brakeMul = m; this.afterRate(); }
  afterRate() { if (this.src) this.src.playbackRate.value = this.eff; this.updateTempoFx(); this.updateBpmText(); }
  setPitchUI(p) { this.q('[data-r="pitch"]').value = p; this.setPitch(p); }
  adjBpm(d) { if (!this.buf) return; this.bpm = Math.max(40, Math.min(240, Math.round((this.bpm + d) * 10) / 10)); this.afterRate(); }
  updateBpmText() { this.q('[data-r="bpm"]').textContent = this.bpm ? (this.bpm * this.tempo).toFixed(1) : '--'; }
  rebase() { const p = this.pos(); this.offset = p; this.startedAt = ctx.currentTime; }

  /* --- transport --- */
  pos() {
    if (!this.buf) return 0;
    if (!this.playing) return this.offset;
    let p = this.offset + (ctx.currentTime - this.startedAt) * this.eff;
    const L = this.loop;
    if (L && p >= L.end) p = L.start + ((p - L.start) % (L.end - L.start));
    return Math.min(p, this.buf.duration);
  }
  togglePlay() { this.playing ? this.pause() : this.play(); }
  play() {
    if (!this.buf) { status('Load a song first (LOAD or DEMO).'); return; }
    if (this.playing) return;
    initAudio();
    if (this.braking) { this.braking = null; }
    this.brakeMul = 1; this.ended = false;
    if (this.offset >= this.buf.duration - 0.05) this.offset = 0;
    const s = ctx.createBufferSource();
    s.buffer = this.buf; s.playbackRate.value = this.eff; s.connect(this.trim);
    if (this.loop) { s.loop = true; s.loopStart = this.loop.start; s.loopEnd = this.loop.end; }
    s.onended = () => { if (this.src === s) { this.src = null; this.playing = false; this.offset = 0; this.ended = true; this.dirty = true; this.refreshBtns(); } };
    s.start(0, this.offset);
    this.src = s; this.playing = true; this.startedAt = ctx.currentTime;
    this.refreshBtns();
  }
  pause() {
    if (!this.playing) return;
    this.offset = this.pos();
    const s = this.src; s.onended = null;
    try { s.stop(); } catch (e) {}
    s.disconnect(); this.src = null; this.playing = false;
    this.refreshBtns(); this.dirty = true;
  }
  seek(t) {
    if (!this.buf) return;
    const was = this.playing; if (was) this.pause();
    this.offset = Math.max(0, Math.min(this.buf.duration - 0.01, t));
    if (this.loop && (this.offset < this.loop.start || this.offset >= this.loop.end)) { this.loop = null; this.refreshBtns(); }
    this.dirty = true;
    if (was) this.play();
  }
  brake() { if (this.playing && !this.braking) { this.braking = { t0: performance.now(), dur: 1400 }; status('Deck ' + this.id + ' brake'); } }
  cueDown() {
    if (!this.buf) return;
    if (this.playing) { this.pause(); this.offset = this.cue; this.dirty = true; }
    else if (Math.abs(this.offset - this.cue) > 0.05) { this.cue = this.offset; this.dirty = true; status('Cue point set'); }
    else { this.preview = true; this.play(); }
  }
  cueUp() { if (this.preview) { this.preview = false; this.pause(); this.offset = this.cue; this.dirty = true; } }
  sync(silent) {
    const o = this.other;
    if (!this.buf || !o.buf || !this.bpm || !o.bpm) { if (!silent) status('SYNC needs a song with a BPM on both decks.'); return false; }
    const target = o.bpm * o.tempo; let best = null;
    [1, 0.5, 2].forEach(m => { const r = target * m / this.bpm; if (r >= 0.84 && r <= 1.16 && (best === null || Math.abs(r - 1) < Math.abs(best - 1))) best = r; });
    if (best === null) { if (!silent) status('Tempos are too far apart to sync.'); return false; }
    this.setPitchUI(Math.round((best - 1) * 1000) / 10);
    if (!silent) status('Deck ' + this.id + ' synced to ' + target.toFixed(1) + ' BPM');
    return true;
  }

  /* --- loops & hot cues --- */
  toggleLoop(n) {
    if (!this.buf) return;
    if (this.loop && this.loop.beats === n) { this.clearLoop(); return; }
    if (!this.bpm) { status('No BPM found - set it with − / +'); return; }
    const p = this.pos(); let len = n * 60 / this.bpm;
    if (p + len > this.buf.duration) len = this.buf.duration - p;
    if (len < 0.05) return;
    if (this.playing) { this.offset = p; this.startedAt = ctx.currentTime; }
    this.loop = { start: p, end: p + len, beats: n };
    if (this.src) { this.src.loopStart = p; this.src.loopEnd = p + len; this.src.loop = true; }
    this.refreshBtns(); this.dirty = true;
  }
  clearLoop() {
    if (this.playing) { const p = this.pos(); this.offset = p; this.startedAt = ctx.currentTime; if (this.src) this.src.loop = false; }
    this.loop = null; this.refreshBtns(); this.dirty = true;
  }
  hotTap(i) {
    if (!this.buf) return;
    if (this.hot[i] === null) { this.hot[i] = this.pos(); status('Hot cue ' + (i + 1) + ' set'); }
    else { this.seek(this.hot[i]); if (!this.playing) this.play(); }
    this.refreshBtns(); this.dirty = true;
  }
  clearHot(i) { this.hot[i] = null; this.refreshBtns(); this.dirty = true; status('Hot cue ' + (i + 1) + ' cleared'); }

  /* --- loading --- */
  setTrack(buf, name, knownBpm, item) {
    this.pause();
    this.buf = buf; this.name = name; this.item = item || null; this.offset = 0; this.cue = 0; this.ended = false;
    this.hot = [null, null, null, null]; this.loop = null; this.nudge = 0; this.hold = 1; this.brakeMul = 1; this.braking = null;
    this.q('[data-r="pitch"]').value = 0; this.pitch = 0;
    this.q('[data-r="name"]').textContent = name;
    this.computePeaks(); this.bpm = knownBpm || 0;
    this.afterRate(); this.refreshBtns(); this.dirty = true;
    if (!knownBpm) {
      this.q('[data-r="bpm"]').textContent = '...';
      setTimeout(() => {
        this.bpm = detectBPM(buf); if (this.item) this.item.bpm = this.bpm; this.afterRate(); renderLib();
        status(this.bpm ? 'Deck ' + this.id + ': ' + this.bpm + ' BPM detected (fix with − / + if needed)' : 'No BPM found - set it with − / +');
      }, 40);
    } else status('Deck ' + this.id + ' loaded: ' + name);
    renderLib();
  }
  computePeaks() {
    const d = this.buf.getChannelData(0), W = 1000, step = Math.max(1, Math.floor(d.length / W)), pk = new Float32Array(W);
    for (let i = 0; i < W; i++) { let m = 0; const s = i * step, e = Math.min(d.length, s + step); for (let j = s; j < e; j += 8) { const v = Math.abs(d[j]); if (v > m) m = v; } pk[i] = m; }
    let mx = 0; pk.forEach(v => { if (v > mx) mx = v; });
    if (mx > 0) for (let i = 0; i < W; i++) pk[i] /= mx;
    this.peaks = pk;
  }

  /* --- screen --- */
  refreshBtns() {
    const pb = this.q('[data-a="play"]'); pb.classList.toggle('on', this.playing); pb.textContent = this.playing ? '❚❚' : '▶';
    this.el.querySelectorAll('[data-loop]').forEach(b => b.classList.toggle('on', !!this.loop && this.loop.beats === +b.dataset.loop));
    this.el.querySelectorAll('[data-hot]').forEach(b => b.classList.toggle('set', this.hot[+b.dataset.hot] !== null));
  }
  vinylImg(S, col) {
    const key = S + col;
    if (this.vinylKey === key) return this.vinyl;
    const c = document.createElement('canvas'); c.width = c.height = S; const g = c.getContext('2d'), m = S / 2, r = m - 1;
    const gr = g.createRadialGradient(m, m, r * 0.2, m, m, r); gr.addColorStop(0, '#1a2338'); gr.addColorStop(1, '#070b14');
    g.fillStyle = gr; g.beginPath(); g.arc(m, m, r, 0, 7); g.fill();
    g.strokeStyle = 'rgba(120,140,190,.18)'; g.lineWidth = 1;
    for (let rr = r * 0.34; rr < r * 0.97; rr += Math.max(2.5, S / 70)) { g.beginPath(); g.arc(m, m, rr, 0, 7); g.stroke(); }
    g.fillStyle = 'rgba(255,255,255,.06)';
    [[200, 240], [20, 60]].forEach(a => { g.beginPath(); g.moveTo(m, m); g.arc(m, m, r * 0.95, a[0] * Math.PI / 180, a[1] * Math.PI / 180); g.fill(); });
    g.strokeStyle = col; g.lineWidth = Math.max(2, S / 60); g.beginPath(); g.arc(m, m, r * 0.33, 0, 7); g.stroke();
    g.fillStyle = '#0c1424'; g.beginPath(); g.arc(m, m, r * 0.30, 0, 7); g.fill();
    g.fillStyle = col; g.font = 'bold ' + Math.round(S * 0.16) + 'px sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(this.id, m, m + 1);
    g.fillRect(m - 1.5, m - r * 0.30, 3, r * 0.1);
    this.vinyl = c; this.vinylKey = key; return c;
  }
  drawPlatter(dt) {
    const cv = this.q('[data-r="platter"]'), w = cv.clientWidth, dpr = window.devicePixelRatio || 1;
    if (!w) return;
    const px = Math.round(w * dpr); if (cv.width !== px) { cv.width = px; cv.height = px; }
    const col = getComputedStyle(this.el).getPropertyValue('--c').trim() || '#00e5ff';
    if (this.playing) this.angle += 200 * this.eff * dt;
    const g = cv.getContext('2d'), S = px, m = S / 2, ringW = Math.max(3, S / 38), r = m - ringW - 2;
    g.clearRect(0, 0, S, S);
    g.lineWidth = ringW; g.strokeStyle = '#1d2a47'; g.beginPath(); g.arc(m, m, m - ringW / 2 - 1, 0, 7); g.stroke();
    if (this.buf) {
      const f = this.pos() / this.buf.duration;
      g.strokeStyle = col; g.lineCap = 'round'; g.beginPath(); g.arc(m, m, m - ringW / 2 - 1, -Math.PI / 2, -Math.PI / 2 + f * 2 * Math.PI); g.stroke(); g.lineCap = 'butt';
      if (this.loop) { const a = this.loop.start / this.buf.duration, b = this.loop.end / this.buf.duration; g.strokeStyle = '#fbbf24'; g.lineWidth = ringW * 0.5; g.beginPath(); g.arc(m, m, m - ringW * 1.6, -Math.PI / 2 + a * 2 * Math.PI, -Math.PI / 2 + Math.max(b, a + 0.01) * 2 * Math.PI); g.stroke(); }
    }
    g.save(); g.translate(m, m); g.rotate(this.angle * Math.PI / 180);
    g.drawImage(this.vinylImg(Math.round(r * 2), col), -r, -r, r * 2, r * 2); g.restore();
  }
  drawWave() {
    const cv = this.q('[data-r="wave"]'), w = cv.clientWidth, h = cv.clientHeight, dpr = window.devicePixelRatio || 1;
    if (!w || !h) return;
    if (cv.width !== Math.round(w * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, h);
    const col = getComputedStyle(this.el).getPropertyValue('--c').trim() || '#00e5ff';
    if (!this.buf || !this.peaks) { g.fillStyle = '#243456'; g.fillRect(0, h / 2 - 1, w, 2); return; }
    const p = this.pos(), frac = p / this.buf.duration, W = this.peaks.length, mid = h / 2, bw = w / W;
    if (this.loop) { g.fillStyle = 'rgba(251,191,36,.25)'; g.fillRect(this.loop.start / this.buf.duration * w, 0, (this.loop.end - this.loop.start) / this.buf.duration * w, h); }
    g.fillStyle = '#35507f'; g.beginPath();
    for (let i = Math.floor(frac * W); i < W; i++) { const a = this.peaks[i] * (mid - 2); g.rect(i * bw, mid - a, Math.max(1, bw), a * 2 + 1); } g.fill();
    g.fillStyle = col; g.beginPath();
    for (let i = 0; i < Math.floor(frac * W); i++) { const a = this.peaks[i] * (mid - 2); g.rect(i * bw, mid - a, Math.max(1, bw), a * 2 + 1); } g.fill();
    g.fillStyle = '#fbbf24'; g.fillRect(this.cue / this.buf.duration * w - 1, 0, 2, h);
    const hc = ['#34d399', '#fb923c', '#a78bfa', '#f87171'];
    this.hot.forEach((t, i) => { if (t !== null) { g.fillStyle = hc[i]; g.fillRect(t / this.buf.duration * w - 1, 0, 3, h); } });
    g.fillStyle = '#fff'; g.fillRect(frac * w - 1, 0, 2, h);
  }
  tick(dt) {
    const now = performance.now();
    if (this.braking) {
      const t = (now - this.braking.t0) / this.braking.dur;
      if (t >= 1) { this.braking = null; this.pause(); this.brakeMul = 1; this.afterRate(); }
      else this.setBrakeMul(Math.max(0.0001, Math.pow(1 - t, 1.6)));
    }
    if (this.touch && this.playing && now - this.touch.t > 90 && this.hold !== 0) { this.touch.w = 0; this.setHold(0); }
    const p = this.pos();
    if (this.buf) {
      this.q('[data-r="time"]').textContent = fmt(p);
      this.q('[data-r="rem"]').textContent = '-' + fmt((this.buf.duration - p) / Math.max(0.05, this.tempo));
    }
    this.drawPlatter(dt);
    if (this.playing || this.dirty) { this.drawWave(); this.dirty = false; }
  }
}

/* ---------- 4. MIXER ---------- */
let fileTarget = null, curve = 'smooth';
function applyCross() {
  const x = +$('#xfader').value; let a, b;
  if (curve === 'smooth') { a = Math.cos(x * Math.PI / 2); b = Math.sin(x * Math.PI / 2); }
  else { a = Math.min(1, 2 * (1 - x)); b = Math.min(1, 2 * x); }
  decks.A.setCross(a); decks.B.setCross(b);
}
let lvl = 0, lastT = performance.now(), infoT = 0;
const meterBuf = new Float32Array(1024);
function frame(ts) {
  const dt = Math.min(0.1, (ts - lastT) / 1000); lastT = ts;
  decks.A.tick(dt); decks.B.tick(dt);
  autoTick(ts);
  if (analyser) {
    analyser.getFloatTimeDomainData(meterBuf);
    let pk = 0; for (let i = 0; i < meterBuf.length; i++) { const v = Math.abs(meterBuf[i]); if (v > pk) pk = v; }
    lvl = Math.max(pk, lvl * 0.9);
    $('#vu').style.width = Math.max(0, Math.min(100, (20 * Math.log10(lvl + 1e-6) + 48) / 48 * 100)) + '%';
  }
  if (ts - infoT > 500) { infoT = ts; autoInfo(); }
  requestAnimationFrame(frame);
}

/* ---------- 5. DEMO SONGS ---------- */
function makeDemo(kind) {
  const sr = ctx.sampleRate, bpm = kind === 0 ? 124 : 128, beat = 60 / bpm, bars = 16, n = Math.floor(bars * 4 * beat * sr);
  const buf = ctx.createBuffer(2, n, sr), L = buf.getChannelData(0), R = buf.getChannelData(1);
  const add = (t0, dur, fn) => { const i0 = Math.floor(t0 * sr), len = Math.floor(dur * sr); for (let i = 0; i < len && i0 + i < n; i++) { const v = fn(i / sr, t0 + i / sr); L[i0 + i] += v; R[i0 + i] += v; } };
  const bassNotes = kind === 0 ? [55, 55, 65.4, 55, 73.4, 55, 65.4, 82.4] : [49, 49, 58.3, 49, 65.4, 49, 58.3, 73.4];
  const arp = kind === 0 ? [220, 262, 330, 392, 330, 262, 294, 349] : [196, 233, 294, 349, 294, 233, 262, 311];
  const duck = abs => 1 - Math.exp(-((abs % beat)) * 11) * 0.85;
  let prev = 0;
  for (let b = 0; b < bars * 4; b++) {
    const bar = Math.floor(b / 4), t = b * beat;
    add(t, 0.38, tt => Math.sin(2 * Math.PI * (45 * tt + 105 * (1 - Math.exp(-30 * tt)) / 30)) * Math.exp(-tt * 9) * 0.95);
    if (bar >= 1) add(t + beat / 2, 0.09, tt => { const x = Math.random() * 2 - 1; const v = x - prev; prev = x; return v * Math.exp(-tt * 60) * 0.22; });
    if (bar >= 2 && b % 2 === 1) add(t, 0.16, tt => (Math.random() * 2 - 1) * Math.exp(-tt * 24) * 0.3);
    if (bar >= 2) for (let h = 0; h < 2; h++) { const f = bassNotes[(b * 2 + h) % 8]; add(t + h * beat / 2, beat / 2, (tt, abs) => (Math.sin(2 * Math.PI * f * tt) + 0.45 * Math.sin(4 * Math.PI * f * tt) + 0.2 * Math.sin(6 * Math.PI * f * tt)) * Math.exp(-tt * 5) * 0.32 * duck(abs)); }
    if (bar >= 4) for (let s = 0; s < 4; s++) { const f = arp[(b * 4 + s + bar) % 8] * (bar >= 8 && s % 2 ? 2 : 1); add(t + s * beat / 4, beat / 3, (tt, abs) => Math.sin(2 * Math.PI * f * tt) * Math.exp(-tt * 14) * 0.13 * duck(abs)); }
  }
  let mx = 0; for (let i = 0; i < n; i++) mx = Math.max(mx, Math.abs(L[i]));
  const k = mx > 0 ? 0.9 / mx : 1; for (let i = 0; i < n; i++) { L[i] *= k; R[i] *= k; }
  return { buf, bpm, name: kind === 0 ? 'Neon Drive (demo)' : 'Night Pulse (demo)' };
}

/* ---------- 6. SAMPLER ---------- */
function sv(type, f, t, d, dest) { const o = ctx.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, t); o.connect(dest); o.start(t); o.stop(t + d); return o; }
function sn(t, d, dest) { const s = ctx.createBufferSource(); s.buffer = noiseBuf; s.connect(dest); s.start(t, Math.random() * 0.4); s.stop(t + d); }
function gainEnv(t, peak, a, hold, rel) { const g = ctx.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(peak, t + a); g.gain.setValueAtTime(peak, t + a + hold); g.gain.exponentialRampToValueAtTime(0.0001, t + a + hold + rel); g.connect(master); return g; }
const SAMPLES = [
  ['📯 AIRHORN', () => { const t = ctx.currentTime, g = gainEnv(t, 0.5, 0.02, 0.6, 0.35), lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 4200; lp.connect(g); [415, 420, 622, 628, 830].forEach(f => sv('sawtooth', f, t, 1.1, lp)); }],
  ['🚨 SIREN', () => { const t = ctx.currentTime, g = gainEnv(t, 0.35, 0.05, 2.0, 0.3), o = sv('sine', 600, t, 2.5, g); [1, 2, 3].forEach(i => o.frequency.linearRampToValueAtTime(i % 2 ? 1300 : 600, t + i * 0.8)); }],
  ['🔫 LASER', () => { const t = ctx.currentTime, g = gainEnv(t, 0.4, 0.005, 0.05, 0.3), o = sv('sawtooth', 3000, t, 0.5, g); o.frequency.exponentialRampToValueAtTime(120, t + 0.3); }],
  ['💥 IMPACT', () => { const t = ctx.currentTime, g = gainEnv(t, 0.9, 0.005, 0.05, 1.3), lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.setValueAtTime(6000, t); lp.frequency.exponentialRampToValueAtTime(100, t + 1.2); lp.connect(g); sn(t, 1.5, lp); const o = sv('sine', 90, t, 1.2, g); o.frequency.exponentialRampToValueAtTime(30, t + 0.9); }],
  ['🥁 KICK', () => { const t = ctx.currentTime, g = gainEnv(t, 1, 0.002, 0.05, 0.3), o = sv('sine', 150, t, 0.45, g); o.frequency.exponentialRampToValueAtTime(40, t + 0.2); }],
  ['🪘 SNARE', () => { const t = ctx.currentTime, g = gainEnv(t, 0.7, 0.002, 0.02, 0.18), bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1900; bp.connect(g); sn(t, 0.3, bp); sv('triangle', 190, t, 0.2, gainEnv(t, 0.5, 0.002, 0.01, 0.1)); }],
  ['👏 CLAP', () => { const t = ctx.currentTime; [0, 0.012, 0.026].forEach(o => { const g = gainEnv(t + o, 0.7, 0.001, 0.005, o === 0.026 ? 0.18 : 0.02), bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 1500; bp.connect(g); sn(t + o, 0.3, bp); }); }],
  ['📈 RISER', () => { const t = ctx.currentTime, g = gainEnv(t, 0.6, 2.4, 0.1, 0.25), bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = 2; bp.frequency.setValueAtTime(300, t); bp.frequency.exponentialRampToValueAtTime(8000, t + 2.6); bp.connect(g); sn(t, 2.8, bp); }]
];
function buildPads() {
  const host = $('#pads');
  SAMPLES.forEach(s => {
    const b = document.createElement('button'); b.className = 'pad'; b.textContent = s[0];
    b.addEventListener('pointerdown', e => { e.preventDefault(); initAudio(); s[1](); });
    host.appendChild(b);
  });
}

/* ---------- 7. LIBRARY ---------- */
const lib = []; let libId = 0;
function addFile(file) {
  const ex = lib.find(i => i.file && i.file.name === file.name && i.file.size === file.size);
  if (ex) return ex;
  const it = { id: ++libId, name: file.name.replace(/\.[^.]+$/, ''), file, bpm: 0 };
  lib.push(it); return it;
}
function demoItem(k) {
  let it = lib.find(i => i.demo === k);
  if (!it) { it = { id: ++libId, name: k === 0 ? 'Neon Drive (demo)' : 'Night Pulse (demo)', demo: k, bpm: k === 0 ? 124 : 128 }; lib.push(it); }
  return it;
}
async function loadItem(item, deck) {
  initAudio(); deck.loading = true;
  deck.q('[data-r="name"]').textContent = 'Loading ' + item.name + ' ...';
  try {
    if (item.demo !== undefined) { await sleep(25); const d = makeDemo(item.demo); deck.setTrack(d.buf, item.name, item.bpm, item); }
    else { const ab = await item.file.arrayBuffer(); const buf = await ctx.decodeAudioData(ab); deck.setTrack(buf, item.name, item.bpm || 0, item); }
  } catch (e) {
    deck.q('[data-r="name"]').textContent = 'Could not read that file';
    status('Could not decode that file. Try MP3, M4A, WAV or OGG.');
  }
  deck.loading = false; renderLib();
}
function renderLib() {
  const host = $('#libList'); if (!host) return;
  if (!lib.length) { host.innerHTML = '<p class="note">No songs yet. Tap "Add songs".</p>'; return; }
  host.innerHTML = '';
  lib.forEach(it => {
    const row = document.createElement('div');
    row.className = 'li' + (decks.A.item === it ? ' ina' : '') + (decks.B.item === it ? ' inb' : '');
    row.innerHTML = `<div class="nm">${it.name.replace(/</g, '&lt;')}<small>${it.bpm ? it.bpm + ' BPM' : (it.demo !== undefined ? 'demo' : 'tap A or B to analyse')}</small></div>
      <button class="la">A</button><button class="lb">B</button><button class="lx">✕</button>`;
    row.querySelector('.la').onclick = () => { loadItem(it, decks.A); status('Loading onto Deck A'); };
    row.querySelector('.lb').onclick = () => { loadItem(it, decks.B); status('Loading onto Deck B'); };
    row.querySelector('.lx').onclick = () => { lib.splice(lib.indexOf(it), 1); renderLib(); };
    host.appendChild(row);
  });
}

/* ---------- 8. AUTO DJ ---------- */
const auto = { on: false, trans: 8, shuffle: false, beat: true, active: null, fading: null, idx: 0, starting: false };
function autoNext() {
  if (!lib.length) { demoItem(0); demoItem(1); }
  if (auto.shuffle && lib.length > 1) { let k; do { k = Math.floor(Math.random() * lib.length); } while (k === auto.idx % lib.length); auto.idx = k + 1; return lib[k]; }
  const it = lib[auto.idx % lib.length]; auto.idx++; return it;
}
async function autoStart() {
  initAudio(); auto.starting = true; auto.on = true; auto.fading = null; auto.idx = 0; renderAutoBtn();
  await loadItem(autoNext(), decks.A); await loadItem(autoNext(), decks.B);
  decks.A.pause(); decks.B.pause();
  $('#xfader').value = 0; applyCross();
  decks.A.play(); auto.active = decks.A; auto.starting = false;
  status('Auto DJ started');
}
function autoStop() { auto.on = false; auto.fading = null; auto.starting = false; renderAutoBtn(); status('Auto DJ stopped'); }
function renderAutoBtn() { const b = $('#autoBtn'); b.textContent = auto.on ? '■ STOP AUTO DJ' : '▶ START AUTO DJ'; b.classList.toggle('live', auto.on); }
function autoTick(now) {
  if (!auto.on || auto.starting || !auto.active) return;
  const cur = auto.active, nxt = cur.other;
  if (auto.fading) {
    const f = auto.fading, t = (now - f.t0) / (auto.trans * 1000);
    if (t >= 1) {
      $('#xfader').value = f.to; applyCross(); cur.pause(); auto.active = nxt; auto.fading = null;
      cur.loading = true; loadItem(autoNext(), cur).then(() => { cur.loading = false; });
    } else { $('#xfader').value = f.from + (f.to - f.from) * t; applyCross(); }
    return;
  }
  if (cur.playing && cur.buf) {
    const rem = (cur.buf.duration - cur.pos()) / Math.max(0.05, cur.tempo);
    if (rem <= auto.trans + 0.3 && nxt.buf && !nxt.loading && !nxt.playing) {
      if (auto.beat) nxt.sync(true);
      nxt.seek(0); nxt.play();
      auto.fading = { t0: now, from: +$('#xfader').value, to: nxt === decks.B ? 1 : 0 };
    }
  } else if (cur.ended && nxt.buf && !nxt.loading) {
    cur.ended = false; $('#xfader').value = nxt === decks.B ? 1 : 0; applyCross();
    nxt.seek(0); nxt.play(); auto.active = nxt;
    cur.loading = true; loadItem(autoNext(), cur).then(() => { cur.loading = false; });
  }
}
function autoInfo() {
  const el = $('#autoInfo'); if (!el) return;
  if (!auto.on) { el.innerHTML = 'Auto DJ is off. ' + (lib.length ? lib.length + ' song(s) in your library.' : 'No songs added: demo beats will be used.'); return; }
  const cur = auto.active, nxt = cur && cur.other;
  el.innerHTML = auto.starting ? 'Starting...' :
    '<b>Now playing (' + cur.id + '):</b> ' + (cur.name || '-') + '<br><b>Next (' + nxt.id + '):</b> ' + (nxt.name || 'loading...') +
    (auto.fading ? '<br><b>Blending...</b>' : '<br>Blend starts ' + auto.trans + 's before the end.');
}

/* ---------- 9. RECORDING ---------- */
let rec = null, recChunks = [], recT0 = 0, recTimer = null;
function toggleRec() {
  initAudio();
  if (rec) { rec.stop(); return; }
  if (!window.MediaRecorder) { status('Recording is not supported on this device.'); return; }
  const mt = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'].find(t => MediaRecorder.isTypeSupported(t));
  rec = new MediaRecorder(recDest.stream, mt ? { mimeType: mt } : undefined); recChunks = [];
  rec.ondataavailable = e => { if (e.data && e.data.size) recChunks.push(e.data); };
  rec.onstop = () => {
    const type = (rec && rec.mimeType) || mt || 'audio/webm'; rec = null; clearInterval(recTimer);
    const b = $('#rec'); b.classList.remove('live'); b.innerHTML = '● Start Recording <span id="recT"></span>';
    saveBlob(new Blob(recChunks, { type }), type);
  };
  rec.start(1000); recT0 = Date.now();
  const b = $('#rec'); b.classList.add('live');
  recTimer = setInterval(() => { const s = Math.floor((Date.now() - recT0) / 1000); b.innerHTML = '■ Stop Recording ' + Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); }, 500);
  b.innerHTML = '■ Stop Recording 0:00'; status('Recording the master mix...');
}
function saveBlob(blob, type) {
  const d = new Date(), p = x => String(x).padStart(2, '0');
  const ext = /ogg/.test(type) ? 'ogg' : /mp4/.test(type) ? 'm4a' : 'webm';
  const name = `CrossDJ-mix-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}.${ext}`;
  if (window.AndroidBridge) {
    const fr = new FileReader();
    fr.onload = () => { status(window.AndroidBridge.saveFile(name, type.split(';')[0], String(fr.result).split(',')[1] || '')); };
    fr.readAsDataURL(blob);
  } else {
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); status('Saved ' + name);
  }
}

/* ---------- 10. START-UP ---------- */
decks.A = new Deck('A'); decks.B = new Deck('B');
decks.A.other = decks.B; decks.B.other = decks.A;
buildPads(); renderLib();

$('#splash').addEventListener('pointerdown', () => { initAudio(); $('#splash').classList.add('hidden'); });
document.querySelectorAll('.tab').forEach(t => t.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === t));
  ['mix', 'lib', 'auto'].forEach(n => $('#tab-' + n).classList.toggle('hidden', n !== t.dataset.tab));
  decks.A.dirty = decks.B.dirty = true;
}));
$('#fileDeck').addEventListener('change', e => { const f = e.target.files[0]; if (f && fileTarget) loadItem(addFile(f), fileTarget); });
$('#fileLib').addEventListener('change', e => { const fs = [...e.target.files]; fs.forEach(addFile); renderLib(); if (fs.length) status(fs.length + ' song(s) added to your library'); });
$('#addSongs').addEventListener('click', () => { $('#fileLib').value = ''; $('#fileLib').click(); });
$('#addDemos').addEventListener('click', () => { demoItem(0); demoItem(1); renderLib(); status('Demo beats added'); });
$('#master').addEventListener('input', e => { if (master) master.gain.value = +e.target.value; });
$('#masterLbl').addEventListener('click', () => { $('#master').value = 0.85; if (master) master.gain.value = 0.85; });
$('#xfader').addEventListener('input', applyCross);
$('#xfCenter').addEventListener('click', () => { $('#xfader').value = 0.5; applyCross(); });
$('#curve').addEventListener('click', () => { curve = curve === 'smooth' ? 'sharp' : 'smooth'; $('#curve').textContent = 'CURVE: ' + curve.toUpperCase(); applyCross(); });
$('#rec').addEventListener('click', toggleRec);
$('#autoBtn').addEventListener('click', () => { auto.on ? autoStop() : autoStart(); });
$('#autoTrans').addEventListener('input', e => { auto.trans = +e.target.value; $('#autoTransV').textContent = auto.trans + 's'; });
$('#autoShuffle').addEventListener('click', e => { auto.shuffle = !auto.shuffle; e.target.textContent = 'SHUFFLE: ' + (auto.shuffle ? 'ON' : 'OFF'); e.target.classList.toggle('on', auto.shuffle); });
$('#autoBeat').addEventListener('click', e => { auto.beat = !auto.beat; e.target.textContent = 'BEAT MATCH: ' + (auto.beat ? 'ON' : 'OFF'); e.target.classList.toggle('on', auto.beat); });
$('#helpBtn').addEventListener('click', () => $('#help').classList.remove('hidden'));
$('#helpClose').addEventListener('click', () => $('#help').classList.add('hidden'));
window.addEventListener('resize', () => { decks.A.dirty = decks.B.dirty = true; });
requestAnimationFrame(frame);
